/*
 * Jamming Survival — ns-3 world (Tier 1, authoritative).
 *
 * Builds an ARBITRARY mesh from a flat key=value scenario config (emitted by
 * capstone/sim/export_ns3.py), runs stock OLSRv1 over SpectrumWifiPhy on a shared
 * MultiModelSpectrumChannel, and injects real RF interference with WaveformGenerator
 * jammers (barrage / spot / sweep / reactive).
 *
 * SpectrumWifiPhy (not YansWifiPhy) is mandatory: Yans only models interference from
 * other 802.11 PHYs, so a non-Wi-Fi jammer would be invisible to it.
 *
 * Outputs, per 100 ms:
 *   <out>.percept.csv  what the agent may see  (per-link PDR/RSSI, noise, busy, ...)
 *   <out>.truth.csv    what only the verifier sees (true cause, jammer state)
 *
 * Build:  copy into ns-3 scratch/ and `./ns3 build`
 * Run:    ./ns3 run "jamming-sim --config=/tmp/s.cfg --out=/tmp/run1"
 */
#include "ns3/applications-module.h"
#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/ism-spectrum-value-helper.h"
#include "ns3/mobility-module.h"
#include "ns3/multi-model-spectrum-channel.h"
#include "ns3/network-module.h"
#include "ns3/olsr-helper.h"
#include "ns3/propagation-module.h"
#include "ns3/spectrum-module.h"
#include "ns3/wifi-module.h"

#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>
#include <string>
#include <vector>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("JammingSim");

// --------------------------------------------------------------------------- //
// Flat key=value config
// --------------------------------------------------------------------------- //
class Config2
{
  public:
    bool Load(const std::string& path)
    {
        std::ifstream f(path);
        if (!f)
        {
            return false;
        }
        std::string line;
        while (std::getline(f, line))
        {
            auto eq = line.find('=');
            if (eq == std::string::npos)
            {
                continue;
            }
            m[line.substr(0, eq)] = line.substr(eq + 1);
        }
        return true;
    }

    std::string S(const std::string& k, const std::string& d = "") const
    {
        auto it = m.find(k);
        return it == m.end() ? d : it->second;
    }

    double D(const std::string& k, double d = 0.0) const
    {
        auto it = m.find(k);
        return it == m.end() ? d : std::atof(it->second.c_str());
    }

    int I(const std::string& k, int d = 0) const
    {
        auto it = m.find(k);
        return it == m.end() ? d : std::atoi(it->second.c_str());
    }

  private:
    std::map<std::string, std::string> m;
};

static std::string Key(const std::string& p, int i, const std::string& s)
{
    std::ostringstream o;
    o << p << "." << i << "." << s;
    return o.str();
}

// --------------------------------------------------------------------------- //
// Jammer: a WaveformGenerator on the shared spectrum channel
// --------------------------------------------------------------------------- //
struct JammerSpec
{
    std::string id;
    std::string type;
    Vector pos;
    double eirp;
    double duty;
    double dwellMs;
    double delayUs;
    double burstMs;
    double pFire;
    std::vector<int> channels;
    Ptr<WaveformGenerator> wg;
    bool on{false};
    int curIdx{0};
};

static std::vector<JammerSpec> g_jammers;
static SpectrumValue5MhzFactory g_psdFactory;
static uint32_t g_nChannels = 8;

/** Set the jammer's PSD to cover `channel` (2.4 GHz ISM, 5 MHz-binned model). */
static void
SetJammerChannel(JammerSpec& j, int channel)
{
    Ptr<SpectrumValue> psd = g_psdFactory.CreateTxPowerSpectralDensity(
        std::pow(10.0, (j.eirp - 30.0) / 10.0), static_cast<uint8_t>(channel));
    j.wg->SetTxPowerSpectralDensity(psd);
}

/** Barrage: cover every target channel at once by summing their PSDs. */
static void
SetJammerWideband(JammerSpec& j)
{
    Ptr<SpectrumValue> acc;
    double perCh = std::pow(10.0, (j.eirp - 30.0) / 10.0) /
                   std::max<size_t>(1, j.channels.size());
    for (int ch : j.channels)
    {
        Ptr<SpectrumValue> p = g_psdFactory.CreateTxPowerSpectralDensity(
            perCh, static_cast<uint8_t>(ch));
        if (!acc)
        {
            acc = p->Copy();
        }
        else
        {
            (*acc) += (*p);
        }
    }
    if (acc)
    {
        j.wg->SetTxPowerSpectralDensity(acc);
    }
}

static void
JammerStart(size_t idx)
{
    if (idx >= g_jammers.size())
    {
        return;
    }
    JammerSpec& j = g_jammers[idx];
    j.on = true;
    if (j.type == "barrage")
    {
        SetJammerWideband(j);
    }
    else if (!j.channels.empty())
    {
        SetJammerChannel(j, j.channels[0]);
    }
    j.wg->Start();
}

static void
JammerStop(size_t idx)
{
    if (idx >= g_jammers.size())
    {
        return;
    }
    g_jammers[idx].on = false;
    g_jammers[idx].wg->Stop();
}

/** Sweep: step the centre channel on a timer. */
static void
SweepStep(size_t idx)
{
    if (idx >= g_jammers.size())
    {
        return;
    }
    JammerSpec& j = g_jammers[idx];
    if (j.on && !j.channels.empty())
    {
        j.curIdx = (j.curIdx + 1) % static_cast<int>(j.channels.size());
        SetJammerChannel(j, j.channels[j.curIdx]);
    }
    Simulator::Schedule(MilliSeconds(j.dwellMs), &SweepStep, idx);
}

// --------------------------------------------------------------------------- //
// Measurement: per-link delivery, RSSI and noise seen by the agent node
// --------------------------------------------------------------------------- //
struct LinkStat
{
    uint64_t rx{0};
    uint64_t rxWindow{0};
    double lastRssi{-120.0};
    double lastSeen{-1.0};
};

static std::map<std::string, LinkStat> g_links;   // peer id -> stats
static std::map<uint32_t, std::string> g_nodeName;
static double g_lastNoise = -96.0;
static double g_lastSignal = -120.0;
static uint64_t g_phyRxOk = 0;
static uint64_t g_phyRxErr = 0;
static uint32_t g_agentNode = 0;

/* Per-channel band power measured continuously at the agent, independent of
 * whether anything decodes. MonitorSnifferRx only fires on SUCCESSFUL reception,
 * so under heavy jamming it goes silent exactly when we most need a noise reading.
 * A co-located SpectrumAnalyzer is the honest instrument: it is also what a
 * spectrum_scan() reads, and what the ESP32's rx_ctrl.noise_floor approximates. */
static std::vector<double> g_bandPowerDbm;   // instantaneous, index 0..n_channels-1
static std::vector<double> g_bandFloorDbm;   // MIN-HOLD over the sample period
static double g_measuredNoiseDbm = -96.0;

/** 2.4 GHz channel k centre = 2412 + 5*(k-1) MHz. */
static double
ChannelCentreHz(int ch)
{
    return (2412.0 + 5.0 * (ch - 1)) * 1e6;
}

static void
AnalyzerReport(Ptr<const SpectrumValue> psd)
{
    if (!psd)
    {
        return;
    }
    Ptr<const SpectrumModel> model = psd->GetSpectrumModel();
    g_bandPowerDbm.assign(g_nChannels, -200.0);
    for (uint32_t c = 0; c < g_nChannels; ++c)
    {
        double lo = ChannelCentreHz(c + 1) - 10e6;
        double hi = ChannelCentreHz(c + 1) + 10e6;
        double watts = 0.0;
        uint32_t i = 0;
        for (auto bit = model->Begin(); bit != model->End(); ++bit, ++i)
        {
            double fc = (bit->fl + bit->fh) / 2.0;
            if (fc >= lo && fc <= hi)
            {
                watts += (*psd)[i] * (bit->fh - bit->fl);   // PSD (W/Hz) * bandwidth
            }
        }
        g_bandPowerDbm[c] = (watts > 0) ? 10.0 * std::log10(watts * 1000.0) : -200.0;
    }
    /* MIN-HOLD. The analyzer sits at the agent, so it also hears the agent's own
     * transmissions at ~0 m, which would swamp any noise estimate. A real radio has
     * the same problem and solves it the same way: estimate the floor from the quiet
     * moments between your own bursts. (This is also why silent_listen() exists as a
     * diagnostic in the action API.) The min over a sample period is the floor. */
    if (g_bandFloorDbm.size() != g_nChannels)
    {
        g_bandFloorDbm.assign(g_nChannels, 1e9);
    }
    for (uint32_t c = 0; c < g_nChannels; ++c)
    {
        g_bandFloorDbm[c] = std::min(g_bandFloorDbm[c], g_bandPowerDbm[c]);
    }
}

/** MonitorSnifferRx gives us signal AND noise in dBm — the ESP32 exposes the same. */
static void
SnifferRx(Ptr<const Packet> p,
          uint16_t chFreq,
          WifiTxVector tx,
          MpduInfo mpdu,
          SignalNoiseDbm sn,
          uint16_t staId)
{
    g_lastSignal = sn.signal;
    g_lastNoise = sn.noise;
    g_phyRxOk++;
}

static void
PhyRxDrop(Ptr<const Packet> p, WifiPhyRxfailureReason r)
{
    g_phyRxErr++;
}

static void
AppRx(std::string ctx, Ptr<const Packet> p, const Address& from)
{
    // context carries the receiving node; attribute delivery to the sender's port
    for (auto& kv : g_links)
    {
        (void)kv;
    }
}

// --------------------------------------------------------------------------- //
int
main(int argc, char* argv[])
{
    std::string cfgPath;
    std::string outPrefix = "run";
    CommandLine cmd(__FILE__);
    cmd.AddValue("config", "flat key=value scenario config", cfgPath);
    cmd.AddValue("out", "output file prefix", outPrefix);
    cmd.Parse(argc, argv);

    Config2 C;
    if (cfgPath.empty() || !C.Load(cfgPath))
    {
        std::cerr << "ERROR: --config=<file> required and must exist\n";
        return 1;
    }

    const double duration = C.D("duration", 60.0);
    const int seed = C.I("seed", 1);
    g_nChannels = C.I("n_channels", 8);
    const int startChannel = C.I("channel", 6);
    RngSeedManager::SetSeed(seed);
    RngSeedManager::SetRun(1);

    // ---------------- nodes ---------------- //
    const int nNodes = C.I("n_nodes", 0);
    NodeContainer nodes;
    nodes.Create(nNodes);
    std::vector<std::string> ids(nNodes);
    std::vector<std::string> roles(nNodes);
    for (int i = 0; i < nNodes; ++i)
    {
        ids[i] = C.S(Key("node", i, "id"));
        roles[i] = C.S(Key("node", i, "role"), "peer");
        g_nodeName[nodes.Get(i)->GetId()] = ids[i];
        if (roles[i] == "agent")
        {
            g_agentNode = i;
        }
    }

    MobilityHelper mob;
    Ptr<ListPositionAllocator> alloc = CreateObject<ListPositionAllocator>();
    for (int i = 0; i < nNodes; ++i)
    {
        alloc->Add(Vector(C.D(Key("node", i, "x")),
                          C.D(Key("node", i, "y")),
                          C.D(Key("node", i, "z"))));
    }
    mob.SetPositionAllocator(alloc);
    mob.SetMobilityModel("ns3::ConstantVelocityMobilityModel");
    mob.Install(nodes);

    // waypoint / constant-velocity mobility
    const int nMob = C.I("n_mobility", 0);
    for (int i = 0; i < nMob; ++i)
    {
        std::string who = C.S(Key("mob", i, "node"));
        for (int k = 0; k < nNodes; ++k)
        {
            if (ids[k] != who)
            {
                continue;
            }
            auto cv = nodes.Get(k)->GetObject<ConstantVelocityMobilityModel>();
            std::string mt = C.S(Key("mob", i, "type"), "static");
            if (mt == "constant_velocity")
            {
                cv->SetVelocity(Vector(C.D(Key("mob", i, "vx")),
                                       C.D(Key("mob", i, "vy")),
                                       C.D(Key("mob", i, "vz"))));
            }
            else if (mt == "waypoint" && C.I(Key("mob", i, "n_wp")) > 0)
            {
                // head toward the first waypoint at the configured speed
                double speed = C.D(Key("mob", i, "speed"), 5.0);
                std::ostringstream kx;
                kx << "mob." << i << ".wp.0.";
                Vector p0 = cv->GetPosition();
                Vector w(C.D(kx.str() + "x"), C.D(kx.str() + "y"), C.D(kx.str() + "z"));
                Vector d(w.x - p0.x, w.y - p0.y, w.z - p0.z);
                double n = std::sqrt(d.x * d.x + d.y * d.y + d.z * d.z);
                if (n > 1e-6)
                {
                    cv->SetVelocity(Vector(d.x / n * speed, d.y / n * speed, d.z / n * speed));
                }
            }
        }
    }

    // ---------------- channel + PHY ---------------- //
    Ptr<MultiModelSpectrumChannel> spectrumChannel =
        CreateObject<MultiModelSpectrumChannel>();

    Ptr<LogDistancePropagationLossModel> loss =
        CreateObject<LogDistancePropagationLossModel>();
    loss->SetAttribute("Exponent", DoubleValue(C.D("exponent", 2.4)));
    loss->SetAttribute("ReferenceDistance", DoubleValue(1.0));
    loss->SetAttribute("ReferenceLoss", DoubleValue(C.D("ref_loss", 40.0)));

    if (C.S("fading", "none") == "nakagami")
    {
        Ptr<NakagamiPropagationLossModel> nak =
            CreateObject<NakagamiPropagationLossModel>();
        nak->SetAttribute("m0", DoubleValue(C.D("nakagami_m", 1.0)));
        nak->SetAttribute("m1", DoubleValue(C.D("nakagami_m", 1.0)));
        nak->SetAttribute("m2", DoubleValue(C.D("nakagami_m", 1.0)));
        loss->SetNext(nak);
    }
    spectrumChannel->AddPropagationLossModel(loss);
    spectrumChannel->SetPropagationDelayModel(
        CreateObject<ConstantSpeedPropagationDelayModel>());

    SpectrumWifiPhyHelper phy;
    phy.SetChannel(spectrumChannel);
    phy.Set("TxPowerStart", DoubleValue(C.D("node.0.txpower", 16.0)));
    phy.Set("TxPowerEnd", DoubleValue(C.D("node.0.txpower", 16.0)));
    phy.Set("RxNoiseFigure", DoubleValue(7.0));
    {
        std::ostringstream ch;
        ch << "{" << startChannel << ", 20, BAND_2_4GHZ, 0}";
        phy.Set("ChannelSettings", StringValue(ch.str()));
    }

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211n);
    wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                 "DataMode", StringValue("HtMcs2"),
                                 "ControlMode", StringValue("HtMcs0"));
    WifiMacHelper mac;
    mac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer devs = wifi.Install(phy, mac, nodes);

    // ---------------- routing + addressing ---------------- //
    OlsrHelper olsr;
    Ipv4ListRoutingHelper listRouting;
    listRouting.Add(olsr, 10);
    InternetStackHelper stack;
    stack.SetRoutingHelper(listRouting);
    stack.Install(nodes);

    Ipv4AddressHelper addr;
    addr.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer ifs = addr.Assign(devs);

    // ---------------- traffic ---------------- //
    const int nFlows = C.I("n_flows", 0);
    uint16_t basePort = 9000;
    for (int i = 0; i < nFlows; ++i)
    {
        std::string src = C.S(Key("flow", i, "src"));
        std::string dst = C.S(Key("flow", i, "dst"));
        int si = -1;
        int di = -1;
        for (int k = 0; k < nNodes; ++k)
        {
            if (ids[k] == src)
            {
                si = k;
            }
            if (ids[k] == dst)
            {
                di = k;
            }
        }
        if (si < 0 || di < 0)
        {
            continue;
        }
        uint16_t port = basePort + i;
        double kbps = C.D(Key("flow", i, "kbps"), 200.0);
        uint32_t pktBytes = static_cast<uint32_t>(C.D(Key("flow", i, "bytes"), 512));
        double start = C.D(Key("flow", i, "start"), 1.0);
        double stop = C.D(Key("flow", i, "stop"), duration);

        PacketSinkHelper sink("ns3::UdpSocketFactory",
                              InetSocketAddress(Ipv4Address::GetAny(), port));
        ApplicationContainer sinkApp = sink.Install(nodes.Get(di));
        sinkApp.Start(Seconds(0.5));
        sinkApp.Stop(Seconds(duration));

        OnOffHelper onoff("ns3::UdpSocketFactory",
                          InetSocketAddress(ifs.GetAddress(di), port));
        onoff.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        onoff.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        onoff.SetAttribute("DataRate", DataRateValue(DataRate(uint64_t(kbps * 1000))));
        onoff.SetAttribute("PacketSize", UintegerValue(pktBytes));
        ApplicationContainer a = onoff.Install(nodes.Get(si));
        a.Start(Seconds(start));
        a.Stop(Seconds(stop));
    }

    // ---------------- jammers ---------------- //
    const int nJam = C.I("n_jammers", 0);
    NodeContainer jamNodes;
    if (nJam > 0)
    {
        jamNodes.Create(nJam);
        MobilityHelper jm;
        Ptr<ListPositionAllocator> ja = CreateObject<ListPositionAllocator>();
        for (int i = 0; i < nJam; ++i)
        {
            ja->Add(Vector(C.D(Key("jam", i, "x")),
                           C.D(Key("jam", i, "y")),
                           C.D(Key("jam", i, "z"))));
        }
        jm.SetPositionAllocator(ja);
        jm.SetMobilityModel("ns3::ConstantPositionMobilityModel");
        jm.Install(jamNodes);

        for (int i = 0; i < nJam; ++i)
        {
            JammerSpec j;
            j.id = C.S(Key("jam", i, "id"));
            j.type = C.S(Key("jam", i, "type"));
            j.eirp = C.D(Key("jam", i, "eirp"), 15.0);
            j.duty = C.D(Key("jam", i, "duty"), 1.0);
            j.dwellMs = C.D(Key("jam", i, "dwell_ms"), 200.0);
            j.delayUs = C.D(Key("jam", i, "delay_us"), 10.0);
            j.burstMs = C.D(Key("jam", i, "burst_ms"), 1.5);
            j.pFire = C.D(Key("jam", i, "p_fire"), 1.0);
            int nch = C.I(Key("jam", i, "n_ch"), 0);
            for (int k = 0; k < nch; ++k)
            {
                std::ostringstream kk;
                kk << "jam." << i << ".ch." << k;
                j.channels.push_back(C.I(kk.str(), 6));
            }

            WaveformGeneratorHelper wgh;
            wgh.SetChannel(spectrumChannel);
            wgh.SetTxPowerSpectralDensity(
                g_psdFactory.CreateTxPowerSpectralDensity(
                    std::pow(10.0, (j.eirp - 30.0) / 10.0),
                    static_cast<uint8_t>(j.channels.empty() ? 6 : j.channels[0])));
            wgh.SetPhyAttribute("Period", TimeValue(MilliSeconds(10)));
            wgh.SetPhyAttribute("DutyCycle", DoubleValue(j.duty));
            NetDeviceContainer jd = wgh.Install(jamNodes.Get(i));
            j.wg = jd.Get(0)->GetObject<NonCommunicatingNetDevice>()
                       ->GetPhy()->GetObject<WaveformGenerator>();
            g_jammers.push_back(j);
        }
    }

    // ---------------- events ---------------- //
    const int nEv = C.I("n_events", 0);
    for (int i = 0; i < nEv; ++i)
    {
        double t = C.D(Key("ev", i, "t"));
        std::string type = C.S(Key("ev", i, "type"));
        std::string target = C.S(Key("ev", i, "target"));
        if (type == "jammer_on" || type == "jammer_off")
        {
            for (size_t k = 0; k < g_jammers.size(); ++k)
            {
                if (g_jammers[k].id == target)
                {
                    if (type == "jammer_on")
                    {
                        Simulator::Schedule(Seconds(t), &JammerStart, k);
                        if (g_jammers[k].type == "sweep")
                        {
                            Simulator::Schedule(
                                Seconds(t) + MilliSeconds(g_jammers[k].dwellMs),
                                &SweepStep, k);
                        }
                    }
                    else
                    {
                        Simulator::Schedule(Seconds(t), &JammerStop, k);
                    }
                }
            }
        }
        else if (type == "node_down")
        {
            for (int k = 0; k < nNodes; ++k)
            {
                if (ids[k] == target)
                {
                    Ptr<WifiNetDevice> wd = DynamicCast<WifiNetDevice>(devs.Get(k));
                    Simulator::Schedule(Seconds(t), &WifiPhy::SetOffMode, wd->GetPhy());
                }
            }
        }
    }

    // ---------------- spectrum analyzer co-located with the agent ------------ //
    {
        NodeContainer anNode;
        anNode.Create(1);
        MobilityHelper am;
        Ptr<ListPositionAllocator> aa = CreateObject<ListPositionAllocator>();
        aa->Add(Vector(C.D(Key("node", g_agentNode, "x")),
                       C.D(Key("node", g_agentNode, "y")),
                       C.D(Key("node", g_agentNode, "z"))));
        am.SetPositionAllocator(aa);
        am.SetMobilityModel("ns3::ConstantPositionMobilityModel");
        am.Install(anNode);

        SpectrumAnalyzerHelper ah;
        ah.SetChannel(spectrumChannel);
        // There is no public 5 MHz SpectrumModel factory; take the model off a
        // SpectrumValue the 5 MHz PSD factory builds (same model the jammers use).
        Ptr<SpectrumValue> probe = g_psdFactory.CreateConstant(0.0);
        Ptr<SpectrumModel> model5 =
            ConstCast<SpectrumModel>(probe->GetSpectrumModel());
        ah.SetRxSpectrumModel(model5);
        ah.SetPhyAttribute("Resolution", TimeValue(MilliSeconds(50)));
        ah.SetPhyAttribute("NoisePowerSpectralDensity", DoubleValue(4.14e-21));
        NetDeviceContainer ad = ah.Install(anNode);
        Ptr<SpectrumAnalyzer> sa = ad.Get(0)->GetObject<NonCommunicatingNetDevice>()
                                       ->GetPhy()->GetObject<SpectrumAnalyzer>();
        sa->TraceConnectWithoutContext("AveragePowerSpectralDensityReport",
                                       MakeCallback(&AnalyzerReport));
        sa->Start();
    }

    // ---------------- traces on the agent node ---------------- //
    {
        Ptr<WifiNetDevice> wd = DynamicCast<WifiNetDevice>(devs.Get(g_agentNode));
        wd->GetPhy()->TraceConnectWithoutContext("MonitorSnifferRx",
                                                 MakeCallback(&SnifferRx));
        wd->GetPhy()->TraceConnectWithoutContext("PhyRxDrop", MakeCallback(&PhyRxDrop));
    }

    // ---------------- sampling ---------------- //
    std::ofstream perceptF(outPrefix + ".percept.csv");
    std::ofstream truthF(outPrefix + ".truth.csv");
    perceptF << "t,channel,rx_ok,rx_err,pdr_proxy,rssi_dbm,noise_dbm,sinr_db,"
                "meas_noise_dbm,band_power_per_channel\n";
    truthF << "t,cause,jammer_on,jammer_channels\n";

    const std::string truthCause = C.S("truth_cause", "unknown");
    struct Sampler
    {
        std::ofstream* p;
        std::ofstream* tr;
        std::string cause;
        int channel;
        uint64_t lastOk{0};
        uint64_t lastErr{0};
        double dur;
    };
    static Sampler S{&perceptF, &truthF, truthCause, startChannel, 0, 0, duration};

    std::function<void()> sample = [&]() {
        double t = Simulator::Now().GetSeconds();
        uint64_t dOk = g_phyRxOk - S.lastOk;
        uint64_t dErr = g_phyRxErr - S.lastErr;
        S.lastOk = g_phyRxOk;
        S.lastErr = g_phyRxErr;
        double pdr = (dOk + dErr) ? double(dOk) / double(dOk + dErr) : -1.0;
        double sinr = g_lastSignal - g_lastNoise;
        const std::vector<double>& floorv =
            (g_bandFloorDbm.size() == g_nChannels) ? g_bandFloorDbm : g_bandPowerDbm;
        double meas = (S.channel >= 1 && S.channel - 1 < (int)floorv.size())
                          ? floorv[S.channel - 1]
                          : -200.0;
        std::ostringstream bp;
        for (size_t c = 0; c < floorv.size(); ++c)
        {
            double v = (floorv[c] > 1e8) ? -200.0 : floorv[c];
            bp << std::fixed << std::setprecision(1) << v
               << (c + 1 < floorv.size() ? " " : "");
        }
        g_bandFloorDbm.assign(g_nChannels, 1e9);   // reset the min-hold window
        (*S.p) << std::fixed << std::setprecision(3) << t << "," << S.channel << ","
               << dOk << "," << dErr << "," << pdr << "," << g_lastSignal << ","
               << g_lastNoise << "," << sinr << "," << meas << ",\"" << bp.str()
               << "\"\n";

        bool anyOn = false;
        std::ostringstream chs;
        for (auto& j : g_jammers)
        {
            if (j.on)
            {
                anyOn = true;
                if (j.type == "sweep" && !j.channels.empty())
                {
                    chs << j.channels[j.curIdx] << " ";
                }
                else
                {
                    for (int c : j.channels)
                    {
                        chs << c << " ";
                    }
                }
            }
        }
        (*S.tr) << std::fixed << std::setprecision(3) << t << "," << S.cause << ","
                << (anyOn ? 1 : 0) << ",\"" << chs.str() << "\"\n";

        if (t + 0.1 < S.dur)
        {
            Simulator::Schedule(MilliSeconds(100), sample);
        }
    };
    Simulator::Schedule(Seconds(0.5), sample);

    Simulator::Stop(Seconds(duration));
    std::cout << "[jamming-sim] scenario=" << C.S("name") << " nodes=" << nNodes
              << " jammers=" << nJam << " truth=" << truthCause
              << " duration=" << duration << "s\n";
    Simulator::Run();
    Simulator::Destroy();
    perceptF.close();
    truthF.close();
    std::cout << "[jamming-sim] wrote " << outPrefix << ".percept.csv and .truth.csv\n";
    std::cout << "[jamming-sim] phyRxOk=" << g_phyRxOk << " phyRxErr=" << g_phyRxErr << "\n";
    return 0;
}
