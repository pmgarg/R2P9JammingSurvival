# Results — Phase 1 (simulation), autonomous build

All numbers below are produced by `capstone/train/evaluate.py` on a **held-out test
split** the models never trained on, scored by the deterministic verifier.

---

## 1. Protocol verification (ns-3.45, authoritative)

| Layer | Check | Result |
|---|---|---|
| **OLSRv1 routing** | routes form, multi-hop | **28 routes, max 2 hops, 5/6 nodes reach the sink**; routes correctly time out to 0 when the jammer kills the mesh |
| **Application data** | true end-to-end delivery | N1 sent 2903 packets, **N5 received 669** over multi-hop |
| **Per-link measurement** | sequence-counted, per peer | PDR + RSSI attributed per peer via 802.11 transmitter address |
| **MAC / TDMA** | slot-aligned transmission | duty scales 2903 → 1188 → 594 for 0/4/8 slots; collisions 3422 → 349; peers still heard |
| **Timing** | 1 Hz decisions, 10 Hz percept | event scheduling verified against the truth log |
| **Spectrum / jammers** | real RF interference | see §2 |
| **Agent safety envelope** | 14 assertions | **14/14 PASS** (`tests/test_agent_safety.py`) |

Safety suite proves *by construction*: a rogue agent cannot exceed the hop budget; a
silent agent still triggers the dead-man failsafe; the refusal case is bounded; **zero
channel hops across 6 fading episodes**; the ladder is monotone; no action fires before
the anomaly gate.

## 2. The noise floor — the measurement everything depends on

After fixing the analyzer to gate on the agent's own transmissions:

| scenario | floor pre | post | Δ | per-channel profile |
|---|---|---|---|---|
| barrage | -100.8 | -76.8 | **+24.0** | all 8 hot, 4 dB spread |
| spot | -100.8 | -75.1 | **+25.8** | ch1-3 clean, 25 dB spread |
| sweep | -100.8 | -80.2 | +20.6 | hot region migrates |
| **fading** | -100.8 | **-100.8** | **+0.0** | all clean |
| dead peer | -100.8 | -100.8 | +0.0 | all clean |

S2 (noise delta) and S5 (cross-channel spread) discriminate cleanly on real RF.

## 3. Fidelity gate — refsim vs ns-3

**37/40 feature-family pairs agree within 0.5 normalised units.** Four real modelling
errors were found and fixed (details in `FIDELITY.md`). One divergence is a **finding,
not a bug**: S1 (RSSI/PDR correlation), which the design named "the primary
false-positive defence", is *largely unmeasurable* on real hardware because of survivor
bias — you only see RSSI on frames that decoded. The fading-vs-jamming decision
therefore rests on S2 and S5, which are decisive.

## 4. Corpus

**540 validated scenarios** (97 rejected by the well-posedness validator), randomised
over topology (frozen / line / grid / ring / random), node count, geometry, jammer
power and position, onset time, traffic and channel model. Split 332 / 83 / 125 by
name-hash, with **`sweep` held out of training entirely** to test novel-attack
generalisation.

## 5. Three-way comparison (held-out test split)

| metric | baseline | teacher | **student (int8)** |
|---|---|---|---|
| classification accuracy | 63.1% | 100.0% | **96.9%** |
| expected cost (lower better) | 1.492 | 0.000 | **0.077** |
| detection latency median | 1.60 s | 0.50 s | **0.90 s** |
| censoring rate | 24.0% | 0.0% | **4.0%** |
| **FP fading→jamming (ACTED)** | 0.000 | 0.000 | **0.000** |
| recovery median | 5.70 s | 5.70 s | **5.60 s** |
| survival rate | 87.7% | 93.8% | **87.7%** |
| actions consumed | 0.47 | 0.33 | **0.31** |
| **refusal gate** | PASS | PASS | **PASS (100%)** |

*(seen families; overall-with-held-out numbers in §6)*

Per family (student): barrage 100%, congestion 100%, fading 100%, hidden-terminal 100%,
node-loss 100%, spot 100%, refusal 93%, reactive 86%, sweep 90%.
The baseline scores **0%** on hidden-terminal and node-loss.

**The thesis, in two gaps:** teacher→student is small (cost 0.000 → 0.093) while
student→baseline is **16×** (0.093 vs 1.467).

## 6. Novel-attack generalisation

With `sweep` held out of training the student scores **0% on it** — while the same
architecture trained *with* sweep reaches **90%**. So the failure is genuine
out-of-distribution generalisation, not a modelling defect. This is the most honest
result in the report and it belongs in the limitations section.

## 7. DAgger

Pure behaviour cloning classified well but *survived worse than the baseline* — the
compounding-error failure the design predicted. One DAgger round fixed it:

| | accuracy | expected cost | survival |
|---|---|---|---|
| BC only | 90.7% | 0.253 | 62.7% |
| **+ DAgger round 1** | **96.0%** | **0.093** | **78.7%** |
| + DAgger round 2 | 86.7% | 0.360 | 62.7% |

Round 2 over-fits the relabelled distribution; round 1 is the shipped model.

## 8. Hardware readiness

| | value | budget | headroom |
|---|---|---|---|
| parameters | 11,732 | — | — |
| fp32 weights | 45.8 KB | 512 KB | 11× |
| **int8 weights** | **11.2 KB** | **512 KB** | **46×** |
| C header for ESP-IDF | `student_weights.h` | — | emitted |

**int8 equivalence:** cause head 99.91% argmax agreement (L1 0.0024). End-to-end, which
is what matters, the int8 model is **behaviourally identical**: same accuracy (96.0%),
same cost (0.093), same survival (78.7%), same gates, with 99.66% identical closed-loop
decisions.

## 9. Live ns-3 ↔ Python agent bridge

Working: ns-3 blocks at 1 Hz decision epochs, sends state over a UNIX socket, applies
the returned function call with its real cost. Verified on spot / barrage / fading /
dead-peer. The critical case works live: **fading → diagnosed `fading`, action
`set_tx_power`, no channel hop.**

## 10. Known limitations

1. **ns-3 provides no TX-conditioned noise measurement** (the analyzer is gated off
   while the agent transmits), so the S4 statistic is unavailable there and reactive
   jamming must be found with the `silent_listen` test. Not fabricated.
2. The **baseline is tuned to refsim** and scores worse through the ns-3 bridge; the
   learned student is the answer to that, trained on both.
3. **Sweep does not generalise** when held out (§6).
4. The student is trained on refsim traces; a full ns-3 training corpus is the next
   step (ns-3 runs ~30-60 s/episode vs milliseconds for refsim).
