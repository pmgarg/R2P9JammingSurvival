"""
Python side of the AgentBridge: drives a live ns-3 episode at 1 Hz.

ns-3 connects to a UNIX socket, sends one JSON state per decision epoch, and BLOCKS
until we reply with a function call. Because ns-3 is single-threaded, the block stalls
wall-clock time while simulation time stays frozen -- the agent may take as long as it
needs without distorting the experiment.

    python3 -m sim.bridge_server --scenario ../scenarios/spot_single_channel.yaml \
        --ns3 <path-to-jamming-sim-binary> --agent baseline
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent.api import Context
from agent.baseline import BaselineAgent
from agent.controller import LADDER
from percept.features import FeatureExtractor, RawObs, LinkObs, ChannelObs, ScanResult
from scenario.schema import load_scenario
from sim.export_ns3 import to_config

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTRACT = json.load(open(os.path.join(HERE, "contract", "agent_contract.json")))
AGENTS = {"baseline": BaselineAgent}


def state_to_obs(st: dict, ex_prev_scan_t, t) -> tuple[RawObs, ScanResult | None]:
    pdrs = st.get("pdr", []) or []
    rssis = st.get("rssi", []) or []
    hbs = st.get("hb", []) or []
    band = st.get("band", []) or []
    links = {}
    for i in range(len(pdrs)):
        pdr = float(pdrs[i])
        links[f"P{i}"] = LinkObs(
            pdr=pdr,
            rssi_dbm=float(rssis[i]) if i < len(rssis) else -120.0,
            retry_rate=float(st.get("retry", min(1.0, 1.0 - pdr))),
            frames_rx=int(round(pdr * 10)),
            heartbeat_age_s=float(hbs[i]) if i < len(hbs) else 0.0,
            reachable=pdr > 0.1)
    ch = int(st.get("channel", 6))
    floor = band[ch - 1] if 0 < ch <= len(band) else -96.0
    if floor < -199:
        floor = -96.0
    jam = floor > -80.0
    decod = 10.0 * (sum(float(x) for x in pdrs) / len(pdrs)) if pdrs else 0.0
    busy = min(1.0, 0.05 + (0.9 if jam else 0.0) + 0.3 * min(1.0, decod / 20.0))
    scan = None
    if band and (ex_prev_scan_t is None or t - ex_prev_scan_t >= 2.0):
        scan = ScanResult(t=t, channels=[
            ChannelObs(ch=i + 1, noise_dbm=float(band[i]),
                       busy_frac=1.0 if float(band[i]) > -80 else 0.05,
                       decodable_fps=decod if i == ch - 1 else 0.0)
            for i in range(len(band))])
    obs = RawObs(t=t, channel=ch, links=links, noise_dbm=floor,
                 cca_busy_frac=busy, decodable_fps=decod,
                 # ns-3 does NOT provide a TX-conditioned noise measurement: the
                 # spectrum analyzer is gated OFF while we transmit (otherwise it just
                 # measures our own PA). So the S4 statistic is unavailable here and we
                 # must not fabricate it -- we alternate the flag so both of the
                 # extractor's accumulators see the same floor and the delta goes to
                 # zero. Reactive jamming is then found by the silent_listen TEST,
                 # which is exactly why that action exists in the API.
                 own_tx_active=(int(t) % 2 == 0),
                 own_tx_duty=float(st.get("tx_duty", 0.35)),
                 offered_load_norm=float(st.get("load", 0.4)),
                 queue_occupancy=min(1.0, 1.0 - (sum(float(x) for x in pdrs) / len(pdrs) if pdrs else 0)),
                 consecutive_tx_fail=0, pos=(0.0, 0.0, 30.0), vel=(0.0, 0.0, 0.0),
                 scan=scan, budget={"hops_used": int(st.get("hops_used", 0)),
                                    "max_channel_hops": CONTRACT["budgets"]["max_channel_hops"]})
    return obs, scan


def run(scenario_path: str, ns3_bin: str, agent_name: str = "baseline",
        out_prefix: str | None = None, verbose: bool = True) -> dict:
    sc = load_scenario(scenario_path)
    tmpd = tempfile.mkdtemp(prefix="bridge_")
    cfg = os.path.join(tmpd, "s.cfg")
    open(cfg, "w").write(to_config(sc))
    sock_path = os.path.join(tmpd, "agent.sock")
    out_prefix = out_prefix or os.path.join(tmpd, "run")

    srv = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    srv.bind(sock_path)
    srv.listen(1)

    proc = subprocess.Popen(
        [ns3_bin, f"--config={cfg}", f"--out={out_prefix}", f"--sock={sock_path}"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

    srv.settimeout(60)
    conn, _ = srv.accept()
    f = conn.makefile("rwb")

    agent = AGENTS[agent_name]()
    agent.reset()
    ex = FeatureExtractor(sc.n_channels, dt=1.0)
    trace, actions, prev_scan_t = [], [], None
    used = {"hops": 0, "scans": 0, "silent": 0, "moves": 0, "costly": 0}
    tried: dict[tuple, float] = {}
    B = CONTRACT["budgets"]
    WARMUP_S = 5.0     # OLSR convergence + beacon ramp; no diagnosis before this

    while True:
        line = f.readline()
        if not line:
            break
        try:
            st = json.loads(line.decode().strip())
        except Exception:
            continue
        t = float(st.get("t", 0.0))
        obs, scan = state_to_obs(st, prev_scan_t, t)
        if scan:
            prev_scan_t = t
            ex.note_scan(scan)
        feats = ex.update(obs)

        avail = ["no_op", "set_tx_power", "reroute", "change_tdma_slot",
                 "listen_test", "transmit_probe", "neighbor_probe", "load_test"]
        if used["scans"] < B["max_spectrum_scans"]:
            avail.append("spectrum_scan")
        if used["silent"] < B["max_silent_listens"]:
            avail.append("silent_listen")
        if used["hops"] < B["max_channel_hops"] and used["costly"] < B["max_costly_actions"]:
            avail += ["hop_channel", "channel_hop_probe"]
        if used["moves"] < B["max_moves"] and used["costly"] < B["max_costly_actions"]:
            avail += ["move", "mobility_test"]
        avail.append("declare_link_lost")

        # ---- anomaly gate (design §7.2). The Controller does this; the bridge must
        # ---- too, or the agent "diagnoses" a link that is merely warming up.
        if t < WARMUP_S or ex.onset_t is None:
            f.write((json.dumps({"call": "no_op"}) + "\n").encode())
            f.flush()
            if verbose and t >= WARMUP_S:
                pass
            continue

        ctx = Context(t=t, channel=int(st.get("channel", 6)), n_channels=sc.n_channels,
                      peers=[f"P{i}" for i in range(int(st.get("n_links", 0)))],
                      budget={"hops_used": used["hops"]}, available=avail,
                      last_scan=scan, lora_available=sc.lora_available)
        d = agent.decide(feats, ctx)
        if d.call not in avail:
            d.call, d.args = "no_op", {}
        # do not re-issue a remedy that already failed for this same hypothesis
        key = (d.top, d.call)
        if d.call not in ("no_op", "declare_link_lost") and key in tried:
            d.call, d.args = "no_op", {}
        elif d.call != "no_op":
            tried[key] = t
        if d.call in ("hop_channel", "channel_hop_probe"):
            used["hops"] += 1
            used["costly"] += 1
        elif d.call == "spectrum_scan":
            used["scans"] += 1
        elif d.call == "silent_listen":
            used["silent"] += 1
        elif d.call in ("move", "mobility_test"):
            used["moves"] += 1
            used["costly"] += 2

        trace.append({"t": round(t, 2), "top": d.top, "p": round(d.top_p, 3),
                      "belief": {k: round(v, 3) for k, v in d.belief.items()},
                      "unrecoverable": round(d.unrecoverable, 3)})
        if d.call != "no_op":
            actions.append({"t": round(t, 2), "fn": d.call, "args": d.args, "why": d.why})
        if verbose:
            print(f"  t={t:5.1f} links={st.get('n_links')} -> {d.top:<11s} p={d.top_p:.2f} "
                  f"call={d.call}{'' if not d.args else ' ' + json.dumps(d.args)}")

        reply = {"call": d.call}
        reply.update({k: v for k, v in (d.args or {}).items()
                      if isinstance(v, (int, float, str))})
        f.write((json.dumps(reply) + "\n").encode())
        f.flush()
        if d.call == "declare_link_lost":
            break

    try:
        conn.close()
        srv.close()
    except Exception:
        pass
    proc.wait(timeout=120)
    return {"scenario": sc.name, "truth": sc.truth.cause, "trace": trace,
            "actions": actions, "out_prefix": out_prefix}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", required=True)
    ap.add_argument("--ns3", required=True, help="path to the jamming-sim binary")
    ap.add_argument("--agent", default="baseline")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    r = run(a.scenario, a.ns3, a.agent, a.out)
    print(f"\n[bridge] scenario={r['scenario']} truth={r['truth']} "
          f"decisions={len(r['trace'])} actions={[x['fn'] for x in r['actions']]}")


if __name__ == "__main__":
    main()
