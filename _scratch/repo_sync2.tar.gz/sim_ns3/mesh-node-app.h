/*
 * MeshNodeApp — the application/measurement plane for the jamming testbed.
 *
 * Replaces OnOffApplication so that we get, exactly and per-link:
 *   - application-level delivery ratio (sequence-numbered, not a PHY proxy)
 *   - per-peer heartbeat liveness (the S9 statistic)
 *   - real TDMA slotting on the control plane (so change_tdma_slot() means something)
 *
 * Every node runs one. It emits:
 *   BEACON  every beaconInterval  -> broadcast, how peers measure this node's link
 *   DATA    at dataRateKbps       -> unicast to a destination, the mission traffic
 *
 * Each packet carries {srcIdx, seq, kind}. A receiver counts arrivals per source in
 * a sliding window and divides by what should have arrived -> true per-link PDR.
 */
#ifndef MESH_NODE_APP_H
#define MESH_NODE_APP_H

#include "ns3/application.h"
#include "ns3/event-id.h"
#include "ns3/inet-socket-address.h"
#include "ns3/ipv4-address.h"
#include "ns3/nstime.h"
#include "ns3/socket.h"
#include "ns3/traced-callback.h"

#include <map>
#include <vector>

namespace ns3
{

#pragma pack(push, 1)
struct MeshPktHdr
{
    uint32_t srcIdx;
    uint32_t seq;
    uint8_t kind; // 0 = beacon, 1 = data
    uint8_t slot;
};
#pragma pack(pop)

class MeshNodeApp : public Application
{
  public:
    static TypeId GetTypeId();
    MeshNodeApp();
    ~MeshNodeApp() override;

    void Setup(uint32_t myIdx,
               Ipv4Address bcast,
               uint16_t port,
               Time beaconInterval,
               double dataKbps,
               uint32_t pktBytes,
               Ipv4Address dataDst,
               bool hasData);

    /** TDMA: only transmit during our slot. slots<=1 disables slotting (pure CSMA). */
    void SetTdma(uint8_t slot, uint8_t nSlots, Time frame);
    uint8_t GetSlot() const { return m_slot; }
    void SetSlot(uint8_t s) { m_slot = s; }
    void SetTxEnabled(bool e) { m_txEnabled = e; }
    void SetDataRate(double kbps) { m_dataKbps = kbps; }

    /** Per-source receive counters (index -> count), reset by the sampler. */
    const std::map<uint32_t, uint32_t>& RxCounts() const { return m_rxCount; }
    /** Cumulative, never reset -- each consumer diffs against its own snapshot. */
    const std::map<uint32_t, uint32_t>& RxTotals() const { return m_rxTotal; }
    const std::map<uint32_t, double>& LastHeard() const { return m_lastHeard; }
    uint32_t BeaconsSent() const { return m_beaconSeq; }
    uint32_t DataSent() const { return m_dataSeq; }
    uint32_t DataRxTotal() const { return m_dataRx; }
    void ResetWindow() { m_rxCount.clear(); }

    /** True when the current time falls in this node's TDMA slot. */
    bool InMySlot() const;
    /** Delay until the start of this node's next slot (or the plain beacon
     *  interval when slotting is disabled). A TDMA MAC must transmit AT its slot
     *  boundary; scheduling on a free-running timer means most beacons land in
     *  someone else's slot and are suppressed. */
    Time TimeToMySlot() const;

  private:
    void StartApplication() override;
    void StopApplication() override;
    void SendBeacon();
    void SendData();
    void HandleRead(Ptr<Socket> s);

    Ptr<Socket> m_txSock;
    Ptr<Socket> m_rxSock;
    uint32_t m_myIdx{0};
    Ipv4Address m_bcast;
    Ipv4Address m_dataDst;
    uint16_t m_port{9999};
    Time m_beaconInterval{MilliSeconds(100)};
    double m_dataKbps{0.0};
    uint32_t m_pktBytes{512};
    bool m_hasData{false};
    bool m_txEnabled{true};

    uint8_t m_slot{0};
    uint8_t m_nSlots{0}; // 0/1 == no TDMA
    Time m_frame{MilliSeconds(100)};

    uint32_t m_beaconSeq{0};
    uint32_t m_dataSeq{0};
    uint32_t m_dataRx{0};
    EventId m_beaconEv;
    EventId m_dataEv;
    std::map<uint32_t, uint32_t> m_rxCount;
    std::map<uint32_t, uint32_t> m_rxTotal;
    std::map<uint32_t, double> m_lastHeard;
};

} // namespace ns3
#endif
